// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMUL_H
#define XMUL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmul_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Mul_io_BaseAddress;
} XMul_Config;
#endif

typedef struct {
    u64 Mul_io_BaseAddress;
    u32 IsReady;
} XMul;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMul_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMul_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMul_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMul_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMul_Initialize(XMul *InstancePtr, u16 DeviceId);
XMul_Config* XMul_LookupConfig(u16 DeviceId);
int XMul_CfgInitialize(XMul *InstancePtr, XMul_Config *ConfigPtr);
#else
int XMul_Initialize(XMul *InstancePtr, const char* InstanceName);
int XMul_Release(XMul *InstancePtr);
#endif

void XMul_Start(XMul *InstancePtr);
u32 XMul_IsDone(XMul *InstancePtr);
u32 XMul_IsIdle(XMul *InstancePtr);
u32 XMul_IsReady(XMul *InstancePtr);
void XMul_EnableAutoRestart(XMul *InstancePtr);
void XMul_DisableAutoRestart(XMul *InstancePtr);

u32 XMul_Get_out_r(XMul *InstancePtr);
u32 XMul_Get_out_r_vld(XMul *InstancePtr);
void XMul_Set_in_r(XMul *InstancePtr, u32 Data);
u32 XMul_Get_in_r(XMul *InstancePtr);

void XMul_InterruptGlobalEnable(XMul *InstancePtr);
void XMul_InterruptGlobalDisable(XMul *InstancePtr);
void XMul_InterruptEnable(XMul *InstancePtr, u32 Mask);
void XMul_InterruptDisable(XMul *InstancePtr, u32 Mask);
void XMul_InterruptClear(XMul *InstancePtr, u32 Mask);
u32 XMul_InterruptGetEnabled(XMul *InstancePtr);
u32 XMul_InterruptGetStatus(XMul *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
