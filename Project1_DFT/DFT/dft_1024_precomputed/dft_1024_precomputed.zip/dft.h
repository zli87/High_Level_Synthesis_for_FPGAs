//#include <ap_int.h>
#include "ap_axi_sdata.h"
#include "hls_stream.h"

typedef float DTYPE;
#define SIZE 1024 		/* SIZE OF DFT */

void dft(  DTYPE *,   DTYPE *,  DTYPE *,   DTYPE *); //use this for doing the demo//
